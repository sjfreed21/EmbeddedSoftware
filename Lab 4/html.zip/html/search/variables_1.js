var searchData=
[
  ['systemcoreclock_272',['SystemCoreClock',['../system__efm32pg12b_8c.html#aa3cd3e43291e81e795d642b79b6088e6',1,'system_efm32pg12b.c']]],
  ['systemhfrcofreq_273',['SystemHfrcoFreq',['../system__efm32pg12b_8c.html#a019e34c770ed2855a9ce73be796f33d5',1,'system_efm32pg12b.c']]]
];
