var searchData=
[
  ['core_281',['CORE',['../group___c_o_r_e.html',1,'']]]
];
