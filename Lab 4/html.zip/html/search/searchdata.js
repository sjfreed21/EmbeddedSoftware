var indexSectionsWithContent =
{
  0: "acegilrs",
  1: "ai",
  2: "acgils",
  3: "acegilrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions"
};

