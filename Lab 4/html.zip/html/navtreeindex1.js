var NAVTREEINDEX1 =
{
"system__efm32pg12b_8c.html#ace8c3b705bdbdc9172fbc7f2415dfd8b":[3,0,0,0,0,0,0,0,0,0,13],
"system__efm32pg12b_8c.html#acf415d3ffe9ce1a46bef43fb0953c9ea":[3,0,0,0,0,0,0,0,0,0,0],
"system__efm32pg12b_8c.html#ae8a3b3b223a7d08bf9e4d86a259f4e14":[3,0,0,0,0,0,0,0,0,0,9],
"system__efm32pg12b_8c.html#aef32887eb9b08a5dd7db73c35ca7c747":[3,0,0,0,0,0,0,0,0,0,8],
"system__efm32pg12b_8c.html#af2e6aa1120f0e55e38c83d8387625d16":[3,0,0,0,0,0,0,0,0,0,6]
};
