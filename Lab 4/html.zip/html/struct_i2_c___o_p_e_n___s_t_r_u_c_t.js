var struct_i2_c___o_p_e_n___s_t_r_u_c_t =
[
    [ "clhr", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a21fe116060fe1e7dcefef7e0114b18bd", null ],
    [ "enable", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "freq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aacfad457f5366fa9265eb0a89e43f23b", null ],
    [ "master", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a076a973bb9631a8e8a5fe1452f01f0bc", null ],
    [ "out_pin_scl_en", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a6536783ac91eccb69757883d72c00d37", null ],
    [ "out_pin_scl_route", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a4fbc8ac1e3864c936e84de63a43cd468", null ],
    [ "out_pin_sda_en", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#acc66994b6930f4bcb1b73c14b0dfaa44", null ],
    [ "out_pin_sda_route", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#ad384e6ec658e914395061d296ab5f8ee", null ],
    [ "refFreq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a3b647a722e160769390ac1967b22b318", null ]
];