var veml6030_8c =
[
    [ "veml6030_conversion", "veml6030_8c.html#a41f21d78faabeffdcc7f4f28b134987b", null ],
    [ "veml6030_i2c_open", "veml6030_8c.html#a02234254db08b9b64a0f0bba67936ba1", null ],
    [ "veml6030_read", "veml6030_8c.html#a7e997b7be7d33771ff92c65a6f90395c", null ],
    [ "veml6030_write", "veml6030_8c.html#a4e8588b51f6fdf44603132a9788ee267", null ],
    [ "data", "veml6030_8c.html#a1e43bf7d608e87228b625cca2c04d641", null ],
    [ "READ", "veml6030_8c.html#ad7bb90b48f5f020c51f31908189e596b", null ],
    [ "VE_BYTES", "veml6030_8c.html#a75ae357ced8e7ea78f7736d3c066027e", null ],
    [ "WRITE", "veml6030_8c.html#ac1cdfb1261f06ab2297efd5e9cdc33b4", null ]
];