var searchData=
[
  ['veml6030_5fconversion_129',['veml6030_conversion',['../veml6030_8c.html#a41f21d78faabeffdcc7f4f28b134987b',1,'veml6030.c']]],
  ['veml6030_5fi2c_5fopen_130',['veml6030_i2c_open',['../veml6030_8c.html#a02234254db08b9b64a0f0bba67936ba1',1,'veml6030.c']]],
  ['veml6030_5fread_131',['veml6030_read',['../veml6030_8c.html#a7e997b7be7d33771ff92c65a6f90395c',1,'veml6030.c']]],
  ['veml6030_5fwrite_132',['veml6030_write',['../veml6030_8c.html#a4e8588b51f6fdf44603132a9788ee267',1,'veml6030.c']]]
];
