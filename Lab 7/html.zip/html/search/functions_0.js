var searchData=
[
  ['add_5fscheduled_5fevent_83',['add_scheduled_event',['../scheduler_8c.html#a4656e4fa005f4bef2f132423f1fc08c8',1,'scheduler.c']]],
  ['app_5fperipheral_5fsetup_84',['app_peripheral_setup',['../app_8c.html#ab8cdb39575ad0f98ace1c6fbd9c54b83',1,'app.c']]]
];
