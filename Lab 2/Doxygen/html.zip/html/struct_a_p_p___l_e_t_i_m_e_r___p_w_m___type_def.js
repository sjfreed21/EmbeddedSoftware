var struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def =
[
    [ "active_period", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a1f35095c80d0db53cae171e4e89d947f", null ],
    [ "debugRun", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
    [ "enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "out_pin_0_en", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a282598b3f0c3b0995d10b02906545832", null ],
    [ "out_pin_1_en", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#af699d0977554fdb7ace801a05b12655e", null ],
    [ "out_pin_route0", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ad231c74a05a5a201e70e6dc49f3a45ea", null ],
    [ "out_pin_route1", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#adef2082a8109a6519ed8641b62a250e1", null ],
    [ "period", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ae08ac1ff9a62c213c5768ca3a538e546", null ]
];