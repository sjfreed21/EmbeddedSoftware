var searchData=
[
  ['app_5fperipheral_5fsetup_15',['app_peripheral_setup',['../app_8c.html#ab8cdb39575ad0f98ace1c6fbd9c54b83',1,'app.c']]]
];
