var files_dup =
[
    [ "Header_Files", "dir_7fa601e68c2de4afaacab5d8ce270028.html", "dir_7fa601e68c2de4afaacab5d8ce270028" ],
    [ "Source_Files", "dir_bb96d882c0070f32c381d357ff07c040.html", "dir_bb96d882c0070f32c381d357ff07c040" ]
];