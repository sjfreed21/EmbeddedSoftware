var struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e =
[
    [ "busy", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#abbe792bb2cf67584b86443440a194f46", null ],
    [ "bytes", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#accacac85be505b95d6c86ab1d7103e47", null ],
    [ "cb", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#a122fe36b66163fc75c52e75dcb6dfe1e", null ],
    [ "data_addr", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#a5bd07f6e520b6e5983bc44714671c5a9", null ],
    [ "I2Cn", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#ae1d34d97f1ebae0965d2b6b1a3a42d8d", null ],
    [ "state", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2", null ],
    [ "target_addr", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#a287b5e3cb78e144850788113b6ac995d", null ],
    [ "target_reg", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#aded81744e7e969f509e0d4fd2edf15e6", null ],
    [ "w_r", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html#a9acef96c3fd8a5d941ef04435c346898", null ]
];