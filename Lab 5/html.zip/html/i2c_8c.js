var i2c_8c =
[
    [ "DEFINED_STATES", "i2c_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037", [
      [ "Start_CMD", "i2c_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037a313ba07a57d748a6e50551b9d78d98dc", null ],
      [ "Read_CMD", "i2c_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037aea45524dc08c0091346dd11b81ce9452", null ],
      [ "Wait_Read", "i2c_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037ad738b60e93e0a56c3fb36d426786cde2", null ],
      [ "End_Sense", "i2c_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037a4be92afeef0e0b1e257219baff4162a8", null ],
      [ "Stop", "i2c_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037af98d707eb4ed173ccfdbaf4eaa87100d", null ],
      [ "EN_TX", "leuart_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037afd80c9e643413389b99dc1acc6ceda18", null ],
      [ "TX_DATA", "leuart_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037a8d76e3a0585a9b86c4df3f85bfda7621", null ],
      [ "END_TX", "leuart_8c.html#ae180687a5f7ba1f0dc0a2e5fe1848037a8dedf42db360ffa63832fa48fb9ddeee", null ]
    ] ],
    [ "I2C0_IRQHandler", "i2c_8c.html#a8e817e99d2a59e5f48e4ff0c79e7eef5", null ],
    [ "I2C1_IRQHandler", "i2c_8c.html#ac45e5675f6f4e6e1dee2273baf245219", null ],
    [ "i2c_open", "i2c_8c.html#afd501191443ae27fa7ab059461676249", null ],
    [ "i2c_start", "i2c_8c.html#ab2c65ddbaeb6d77807ccbcbf8bacbb43", null ],
    [ "i2c_state", "i2c_8c.html#ab8425935bbb7fe73adbf12676e8e1c3e", null ]
];